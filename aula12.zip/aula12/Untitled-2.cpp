#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;
int main() {
   

    ifstream arquivoStopWords;
    vector<string> listaStopWords;

    ofstream arquivoTextoSemStopwords;
    ifstream arquivoTextoOriginal; // abre e le palavra por palavra, depois comparar VVV


    return 1;
}